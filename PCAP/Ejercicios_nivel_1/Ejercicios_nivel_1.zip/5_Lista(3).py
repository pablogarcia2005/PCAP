n1 = int(input("Número 1: "))
n2 = int(input("Número 2: "))
n3 = int(input("Número 3: "))
n4 = int(input("Número 4: "))
n5 = int(input("Número 5: "))
n6 = int(input("Número 6: "))
numeros = [n1, n2, n3, n4, n5, n6]
print("Números ganadores:", numeros.sort())